"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import type { Progress, SectionType } from "@/types"

interface ProgressContextType {
  progress: Progress[]
  completedExercises: Set<string>
  markExerciseCompleted: (sectionId: SectionType, exerciseId: string) => void
  getTodayProgress: () => { sectionId: SectionType; completed: number; total: number }[]
  getWeekProgress: () => { day: string; completed: number }[]
  getMonthProgress: () => { day: string; completed: number }[]
}

const ProgressContext = createContext<ProgressContextType | undefined>(undefined)

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<Progress[]>([])
  const [completedExercises, setCompletedExercises] = useState<Set<string>>(new Set())

  // Load progress from localStorage on mount
  useEffect(() => {
    const savedProgress = localStorage.getItem("vocal-exercise-progress")
    if (savedProgress) {
      const parsed = JSON.parse(savedProgress)
      setProgress(parsed)

      // Rebuild the set of completed exercises
      const completed = new Set<string>()
      const today = new Date().toISOString().split("T")[0]

      const todayProgress = parsed.find((p: Progress) => p.date === today)
      if (todayProgress) {
        todayProgress.completedSections.forEach((section: any) => {
          section.exercisesCompleted.forEach((exerciseId: string) => {
            completed.add(`${section.sectionId}-${exerciseId}`)
          })
        })
      }

      setCompletedExercises(completed)
    }
  }, [])

  // Save progress to localStorage whenever it changes
  useEffect(() => {
    if (progress.length > 0) {
      localStorage.setItem("vocal-exercise-progress", JSON.stringify(progress))
    }
  }, [progress])

  const markExerciseCompleted = (sectionId: SectionType, exerciseId: string) => {
    const today = new Date().toISOString().split("T")[0]
    const uniqueId = `${sectionId}-${exerciseId}`

    // If already completed today, do nothing
    if (completedExercises.has(uniqueId)) return

    setCompletedExercises((prev) => {
      const updated = new Set(prev)
      updated.add(uniqueId)
      return updated
    })

    setProgress((prev) => {
      const todayIndex = prev.findIndex((p) => p.date === today)

      if (todayIndex >= 0) {
        // Update existing entry for today
        const updated = [...prev]
        const sectionIndex = updated[todayIndex].completedSections.findIndex((s) => s.sectionId === sectionId)

        if (sectionIndex >= 0) {
          // Update existing section
          updated[todayIndex].completedSections[sectionIndex].exercisesCompleted.push(exerciseId)
        } else {
          // Add new section
          updated[todayIndex].completedSections.push({
            sectionId,
            exercisesCompleted: [exerciseId],
          })
        }

        return updated
      } else {
        // Create new entry for today
        return [
          ...prev,
          {
            date: today,
            completedSections: [
              {
                sectionId,
                exercisesCompleted: [exerciseId],
              },
            ],
          },
        ]
      }
    })
  }

  const getTodayProgress = () => {
    const today = new Date().toISOString().split("T")[0]
    const todayProgress = progress.find((p) => p.date === today)

    const sections: SectionType[] = ["breathing", "vibration", "resonance", "articulators"]

    return sections.map((sectionId) => {
      const sectionProgress = todayProgress?.completedSections.find((s) => s.sectionId === sectionId)
      return {
        sectionId,
        completed: sectionProgress?.exercisesCompleted.length || 0,
        total: 3, // Each section has 3 exercises
      }
    })
  }

  const getWeekProgress = () => {
    const today = new Date()
    const days: string[] = []

    // Get the last 7 days
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(today.getDate() - i)
      days.push(date.toISOString().split("T")[0])
    }

    return days.map((day) => {
      const dayProgress = progress.find((p) => p.date === day)
      let completed = 0

      if (dayProgress) {
        dayProgress.completedSections.forEach((section) => {
          completed += section.exercisesCompleted.length
        })
      }

      return {
        day,
        completed,
      }
    })
  }

  const getMonthProgress = () => {
    const today = new Date()
    const days: string[] = []

    // Get the last 30 days
    for (let i = 29; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(today.getDate() - i)
      days.push(date.toISOString().split("T")[0])
    }

    return days.map((day) => {
      const dayProgress = progress.find((p) => p.date === day)
      let completed = 0

      if (dayProgress) {
        dayProgress.completedSections.forEach((section) => {
          completed += section.exercisesCompleted.length
        })
      }

      return {
        day,
        completed,
      }
    })
  }

  return (
    <ProgressContext.Provider
      value={{
        progress,
        completedExercises,
        markExerciseCompleted,
        getTodayProgress,
        getWeekProgress,
        getMonthProgress,
      }}
    >
      {children}
    </ProgressContext.Provider>
  )
}

export function useProgress() {
  const context = useContext(ProgressContext)
  if (context === undefined) {
    throw new Error("useProgress must be used within a ProgressProvider")
  }
  return context
}

