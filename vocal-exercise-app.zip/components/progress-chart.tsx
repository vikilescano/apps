"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface ProgressChartProps {
  data: { day: string; completed: number }[]
  title: string
  description: string
}

export function ProgressChart({ data, title, description }: ProgressChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set dimensions
    const width = canvas.width
    const height = canvas.height
    const padding = 40
    const chartWidth = width - padding * 2
    const chartHeight = height - padding * 2

    // Find max value for scaling
    const maxValue = Math.max(...data.map((d) => d.completed), 5)

    // Draw axes
    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, height - padding)
    ctx.lineTo(width - padding, height - padding)
    ctx.strokeStyle = "#ccc"
    ctx.stroke()

    // Draw bars
    const barWidth = (chartWidth / data.length) * 0.8
    const barSpacing = (chartWidth / data.length) * 0.2

    data.forEach((item, index) => {
      const x = padding + index * (barWidth + barSpacing)
      const barHeight = (item.completed / maxValue) * chartHeight
      const y = height - padding - barHeight

      // Draw bar
      ctx.fillStyle = "#3b82f6"
      ctx.fillRect(x, y, barWidth, barHeight)

      // Draw date label (only for first, middle and last)
      if (index === 0 || index === Math.floor(data.length / 2) || index === data.length - 1) {
        ctx.fillStyle = "#666"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        const date = new Date(item.day)
        const dateLabel = `${date.getDate()}/${date.getMonth() + 1}`
        ctx.fillText(dateLabel, x + barWidth / 2, height - padding + 15)
      }

      // Draw value on top of bar if value > 0
      if (item.completed > 0) {
        ctx.fillStyle = "#333"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.fillText(item.completed.toString(), x + barWidth / 2, y - 5)
      }
    })

    // Draw y-axis labels
    ctx.fillStyle = "#666"
    ctx.font = "10px Arial"
    ctx.textAlign = "right"

    // Draw 0, max/2 and max labels
    ctx.fillText("0", padding - 5, height - padding + 5)
    ctx.fillText((maxValue / 2).toString(), padding - 5, height - padding - chartHeight / 2 + 5)
    ctx.fillText(maxValue.toString(), padding - 5, padding + 5)
  }, [data])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <canvas ref={canvasRef} width={400} height={200} className="w-full h-auto"></canvas>
      </CardContent>
    </Card>
  )
}

