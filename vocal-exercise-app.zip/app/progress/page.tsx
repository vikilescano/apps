"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useProgress } from "@/context/progress-context"
import { sections } from "@/data/sections"
import { ProgressChart } from "@/components/progress-chart"

export default function ProgressPage() {
  const { getTodayProgress, getWeekProgress, getMonthProgress } = useProgress()

  const todayProgress = getTodayProgress()
  const weekProgress = getWeekProgress()
  const monthProgress = getMonthProgress()

  // Calculate total exercises completed today
  const totalCompletedToday = todayProgress.reduce((acc, curr) => acc + curr.completed, 0)
  const totalExercises = todayProgress.reduce((acc, curr) => acc + curr.total, 0)
  const percentageCompleted = Math.round((totalCompletedToday / totalExercises) * 100)

  return (
    <div className="container py-8 max-w-4xl">
      <div className="mb-8">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>
        <h1 className="text-3xl font-bold mb-2">Mi Progreso</h1>
        <p className="text-muted-foreground">Seguimiento de tus ejercicios vocales</p>
      </div>

      <div className="grid gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Resumen de hoy</CardTitle>
            <CardDescription>Tu progreso del día actual</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <div className="flex justify-between text-sm mb-1">
                <span>Progreso total</span>
                <span>{percentageCompleted}%</span>
              </div>
              <div className="w-full bg-secondary rounded-full h-2.5">
                <div className="bg-primary h-2.5 rounded-full" style={{ width: `${percentageCompleted}%` }}></div>
              </div>
            </div>

            <div className="grid gap-4">
              {todayProgress.map((progress) => {
                const sectionData = sections.find((s) => s.id === progress.sectionId)
                return (
                  <div key={progress.sectionId} className="flex items-center gap-4">
                    <div className="flex-grow">
                      <p className="font-medium">{sectionData?.title}</p>
                      <div className="w-full bg-secondary rounded-full h-2.5 mt-1">
                        <div
                          className="bg-primary h-2.5 rounded-full"
                          style={{ width: `${(progress.completed / progress.total) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="text-sm">
                      {progress.completed}/{progress.total}
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="week">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="week">Esta semana</TabsTrigger>
            <TabsTrigger value="month">Este mes</TabsTrigger>
          </TabsList>
          <TabsContent value="week">
            <ProgressChart
              data={weekProgress}
              title="Progreso semanal"
              description="Ejercicios completados en los últimos 7 días"
            />
          </TabsContent>
          <TabsContent value="month">
            <ProgressChart
              data={monthProgress}
              title="Progreso mensual"
              description="Ejercicios completados en los últimos 30 días"
            />
          </TabsContent>
        </Tabs>
      </div>

      <div className="text-center">
        <Button asChild size="lg">
          <Link href="/">Continuar ejercitando</Link>
        </Button>
      </div>
    </div>
  )
}

