"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export function InstallPWA() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [isInstallable, setIsInstallable] = useState(false)
  const [isIOS, setIsIOS] = useState(false)

  useEffect(() => {
    // Detectar si es iOS
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream
    setIsIOS(isIOSDevice)

    // Escuchar el evento beforeinstallprompt
    const handleBeforeInstallPrompt = (e: Event) => {
      // Prevenir que Chrome muestre el diálogo automático
      e.preventDefault()
      // Guardar el evento para usarlo más tarde
      setDeferredPrompt(e)
      // Actualizar UI para mostrar que la app es instalable
      setIsInstallable(true)
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    }
  }, [])

  const handleInstallClick = async () => {
    if (!deferredPrompt) return

    // Mostrar el diálogo de instalación
    deferredPrompt.prompt()

    // Esperar a que el usuario responda
    const { outcome } = await deferredPrompt.userChoice

    // Limpiar el evento guardado
    setDeferredPrompt(null)

    // Ocultar el botón de instalación
    setIsInstallable(false)
  }

  if (!isInstallable && !isIOS) return null

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isInstallable ? (
        <Button onClick={handleInstallClick} className="shadow-lg">
          <Download className="mr-2 h-4 w-4" />
          Instalar aplicación
        </Button>
      ) : isIOS ? (
        <div className="bg-white p-4 rounded-lg shadow-lg border max-w-xs">
          <p className="text-sm mb-2">Para instalar esta aplicación en iOS:</p>
          <ol className="text-xs text-muted-foreground list-decimal pl-4 space-y-1">
            <li>Toca el icono de compartir</li>
            <li>Desplázate y selecciona "Añadir a pantalla de inicio"</li>
          </ol>
        </div>
      ) : null}
    </div>
  )
}

