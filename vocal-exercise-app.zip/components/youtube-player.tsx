"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface YouTubePlayerProps {
  defaultVideoUrl?: string
  allowCustomVideo?: boolean
}

export function YouTubePlayer({ defaultVideoUrl, allowCustomVideo = false }: YouTubePlayerProps) {
  const [videoUrl, setVideoUrl] = useState(defaultVideoUrl || "")
  const [customUrl, setCustomUrl] = useState("")
  const [showCustomInput, setShowCustomInput] = useState(false)

  // Extract YouTube video ID from URL
  const getYouTubeId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/
    const match = url.match(regExp)
    return match && match[2].length === 11 ? match[2] : null
  }

  const videoId = getYouTubeId(videoUrl)

  const handleSubmitCustomUrl = () => {
    if (customUrl) {
      setVideoUrl(customUrl)
      setShowCustomInput(false)
    }
  }

  return (
    <div className="w-full space-y-4">
      {videoId ? (
        <div className="aspect-video w-full">
          <iframe
            width="100%"
            height="100%"
            src={`https://www.youtube.com/embed/${videoId}`}
            title="YouTube video player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="rounded-lg"
          ></iframe>
        </div>
      ) : (
        <div className="aspect-video w-full bg-muted flex items-center justify-center rounded-lg">
          <p className="text-muted-foreground">No hay video seleccionado</p>
        </div>
      )}

      {allowCustomVideo && (
        <div>
          {showCustomInput ? (
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Ingresa URL de YouTube"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
              />
              <Button onClick={handleSubmitCustomUrl}>Aplicar</Button>
            </div>
          ) : (
            <Button variant="outline" onClick={() => setShowCustomInput(true)} className="w-full">
              Usar mi propio video
            </Button>
          )}
        </div>
      )}
    </div>
  )
}

