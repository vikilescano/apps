import Link from "next/link"
import { sections } from "@/data/sections"
import { SectionCard } from "@/components/section-card"
import { Button } from "@/components/ui/button"
import { InstallPWA } from "@/components/install-pwa"

export default function Home() {
  return (
    <div className="container py-8">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold mb-2">Ejercitación Vocal</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {sections.map((section) => (
          <SectionCard key={section.id} section={section} />
        ))}
      </div>

      <div className="text-center">
        <Button asChild size="lg">
          <Link href="/progress">Ver mi progreso</Link>
        </Button>
      </div>

      <InstallPWA />
    </div>
  )
}

