import type { Section } from "@/types"

export const sections: Section[] = [
  {
    id: "breathing",
    title: "Respiración (Apoyo)",
    description: "Aprende a controlar tu respiración para mejorar tu técnica vocal.",
    mainTopics: [
      "Proceso de fonación: Dividido en 4 procesos interrelacionados: respiración, fonación, resonancia y articulación.",
      "Inhalación para cantar: Similar a la inhalación normal, pero regulando la cantidad de aire tomado.",
      "Exhalación para cantar: Controlada, con la participación de los músculos intercostales y abdominales.",
      "Respiración general para cantar: Relajada, sostenida y subordinada a la postura.",
      "Apoyo respiratorio (apoggio): Respiración profunda y lenta, con control de la glotis y la laringe.",
    ],
    practicalTips: {
      title: "Consejos prácticos",
      tips: [
        "La respiración debe ser relajada, aquietada y sostenida.",
        "No es necesario tomar grandes cantidades de aire, sino dosificarlo correctamente.",
        "La postura es clave: una postura correcta facilita la respiración automáticamente.",
        "Evitar tensiones innecesarias; el apoyo respiratorio debe surgir de manera natural.",
        "Inhalar por la boca (más rápido y práctico para cantar).",
        "Probar inhalaciones lentas al principio para tomar conciencia del proceso.",
        "La sensación de la respiración debe llegar hasta la parte baja del abdomen.",
        "Concentrarse en la sensación corporal y no en el pensamiento excesivo.",
        "Integrar cuerpo, mente y espíritu; pensar menos y sentir más.",
        "Usar imágenes mentales para facilitar la coordinación respiratoria.",
      ],
    },
    exercises: [
      {
        id: "breathing-types",
        title: "Respiración alta, media y profunda",
        description: "Probar diferentes tipos de respiración con distintas posturas.",
        steps: [
          {
            id: "step-1",
            instruction: "Respiración alta",
            description:
              "Inhala intentando llevar el aire solo a la parte superior del pecho. Observa cómo se elevan los hombros y la clavícula. Exhala lentamente.",
          },
          {
            id: "step-2",
            instruction: "Respiración media",
            description:
              "Inhala dirigiendo el aire hacia la parte media del pecho. Siente cómo se expanden las costillas. Exhala lentamente.",
          },
          {
            id: "step-3",
            instruction: "Respiración profunda",
            description:
              "Inhala profundamente, llevando el aire hasta la parte baja del abdomen. Siente cómo se expande el diafragma. Exhala lentamente controlando el flujo de aire.",
          },
        ],
      },
      {
        id: "sustained-staccato",
        title: "Soplo sostenido y staccato",
        description: "Practicar diferentes tipos de exhalación para mejorar el control del aire.",
        steps: [
          {
            id: "step-1",
            instruction: "Soplo sostenido",
            description:
              'Inhala profundamente y exhala produciendo un sonido "sss" continuo y constante durante el mayor tiempo posible. Mantén la misma intensidad desde el principio hasta el final.',
          },
          {
            id: "step-2",
            instruction: "Staccato",
            description:
              'Inhala profundamente y exhala produciendo sonidos cortos y rápidos "s-s-s-s" como si estuvieras riendo. Siente la participación de los músculos abdominales.',
          },
          {
            id: "step-3",
            instruction: "Escalera de vocalización",
            description:
              "Realiza una escala ascendente y descendente primero con soplo sostenido y luego con staccato. Observa la diferencia en la participación muscular.",
          },
        ],
      },
      {
        id: "singing-practice",
        title: "Práctica en el canto",
        description: "Aplicar los conceptos de respiración a una canción.",
        steps: [
          {
            id: "step-1",
            instruction: "Cantar sin pensar en la respiración",
            description:
              "Canta una canción de tu elección sin pensar conscientemente en la respiración, simplemente sintiendo cómo se dosifica el aire de forma natural.",
          },
          {
            id: "step-2",
            instruction: 'Cantar con "sss"',
            description:
              'Canta la misma canción por estrofas reemplazando la letra por un sonido "sss" suave, enfocándote en la entrada y salida del aire.',
          },
          {
            id: "step-3",
            instruction: "Cantar solo con aire",
            description:
              "Canta la canción por estrofas sin producir sonido, solo con el movimiento del aire, como si susurraras sin voz.",
          },
          {
            id: "step-4",
            instruction: "Cantar con respiración consciente",
            description:
              "Finalmente, canta la canción completa manteniendo una respiración profunda y observando los cambios en la sensación.",
          },
        ],
        videoUrl: "https://www.youtube.com/watch?v=MKdOLI3nUVs",
        allowCustomVideo: true,
      },
    ],
  },
  {
    id: "vibration",
    title: "Vibración (Cuerdas Vocales)",
    description: "Aprende sobre la producción del sonido y el funcionamiento de las cuerdas vocales.",
    mainTopics: [
      "Cuerdas vocales: Estructura compuesta por varias capas (mucosa, ligamento y músculo vocal).",
      "Ubicación: Dentro de la laringe, sobre la tráquea, y protegidas por la epiglotis.",
      "Función: Vibran para producir sonido al abrirse y cerrarse con el flujo de aire.",
      "Teoría mioelástica aerodinámica: Combinación de elasticidad de las cuerdas y presión de aire subglótica.",
      "Ciclo vibratorio: Las cuerdas se abren y cierran, generando ondas de sonido.",
      "Altura del sonido (tono): Depende de la frecuencia de vibración.",
      "Intensidad del sonido: Determinada por la fuerza del aire liberado.",
      "Movimiento de la laringe: Desciende al bostezar y sube al tragar.",
      "Cuerdas vocales verdaderas y falsas: Las verdaderas producen el sonido, las falsas protegen.",
      "Glotis: Espacio entre las cuerdas vocales, clave para la fonación.",
    ],
    practicalTips: {
      title: "A tener en cuenta",
      tips: [
        "Relajación: Evitar tensiones innecesarias en la garganta y el cuello.",
        "Coordinación: La vibración depende de la tensión muscular de las cuerdas y la presión del aire.",
        "Postura: Mantener una postura erguida para facilitar el movimiento libre de la laringe.",
        "Control del aire: Dosificar la presión de aire para evitar sonidos presionados o aireados.",
        "Movimiento natural: Permitir que las cuerdas vibren libremente sin forzar su cierre o apertura.",
        "Uso de la laringe: Evitar que suba demasiado para mantener un sonido claro y relajado.",
        "Imaginar el sonido como un flujo suave y constante, no como un esfuerzo.",
        "Concentrarse en la sensación de vibración en las cuerdas vocales.",
        "Visualizar la laringe en una posición baja y relajada, como al bostezar.",
        "Mantener la garganta relajada y evitar tensionar los músculos del cuello.",
      ],
    },
    exercises: [
      {
        id: "glissando",
        title: "Glissando (arrastre de notas)",
        description:
          "Deslizar suavemente de una nota grave a una aguda y viceversa, sintiendo la elongación de las cuerdas vocales.",
        steps: [
          {
            id: "step-1",
            instruction: "Preparación",
            description:
              "Adopta una postura relajada pero erguida. Asegúrate de que tu cuello y hombros estén libres de tensión.",
          },
          {
            id: "step-2",
            instruction: "Glissando ascendente",
            description:
              'Comienza con un sonido grave y deslízate suavemente hacia un sonido agudo, como una sirena ascendente. Usa la vocal "u" para este ejercicio.',
          },
          {
            id: "step-3",
            instruction: "Glissando descendente",
            description:
              'Ahora comienza con un sonido agudo y deslízate hacia un sonido grave, como una sirena descendente. Usa la vocal "u" para este ejercicio.',
          },
        ],
        videoUrl: "https://www.youtube.com/watch?v=hFkZCweeU9g",
      },
      {
        id: "controlled-vibration",
        title: "Ejercicio de vibración controlada",
        description: "Producir un sonido sostenido variando la intensidad sin forzar las cuerdas.",
        steps: [
          {
            id: "step-1",
            instruction: "Sonido sostenido",
            description:
              'Produce un sonido sostenido con la vocal "a" en una nota media cómoda para ti. Mantén el sonido estable durante 5-10 segundos.',
          },
          {
            id: "step-2",
            instruction: "Variación de intensidad",
            description:
              "Manteniendo la misma nota, varía gradualmente la intensidad de suave a fuerte y luego de fuerte a suave, sin forzar las cuerdas vocales.",
          },
          {
            id: "step-3",
            instruction: "Relajación de la laringe",
            description:
              "Imita un bostezo suave para bajar la laringe y sentir la apertura de la garganta. Luego, produce nuevamente el sonido sostenido notando la diferencia.",
          },
        ],
      },
      {
        id: "tone-exploration",
        title: "Exploración de tonos",
        description:
          "Cantar escalas ascendentes y descendentes, prestando atención a cómo las cuerdas se tensan y relajan.",
        steps: [
          {
            id: "step-1",
            instruction: "Escalas ascendentes",
            description:
              'Canta una escala ascendente con la vocal "i", prestando atención a cómo las cuerdas vocales se tensan a medida que subes de tono.',
          },
          {
            id: "step-2",
            instruction: "Escalas descendentes",
            description:
              'Canta una escala descendente con la vocal "o", sintiendo cómo las cuerdas vocales se relajan a medida que bajas de tono.',
          },
          {
            id: "step-3",
            instruction: "Combinación",
            description:
              "Combina ambos ejercicios, subiendo y bajando por la escala con diferentes vocales, prestando atención a la sensación en tu garganta.",
          },
        ],
        videoUrl: "https://www.youtube.com/watch?v=zWGb9FWn6mE&t=12s",
      },
    ],
  },
  {
    id: "resonance",
    title: "Resonancia",
    description: "Aprende a utilizar los resonadores del cuerpo para amplificar y enriquecer tu voz.",
    mainTopics: [
      "Las ondas de sonido producidas por las cuerdas vocales se amplifican en los resonadores del cuerpo.",
      "Los resonadores son espacios vibrantes que refuerzan el sonido existente.",
      "Porción fija: Faringe nasal y fosas nasales (refuerzan sonidos agudos).",
      "Porción móvil: Boca (refuerza sonidos de forma pareja).",
      "Porción muy móvil: Faringe media y laringe (refuerzan sonidos graves).",
      "Los resonadores producen armónicos que dan características únicas a la voz.",
      "La lengua, el paladar, los cachetes y la mandíbula alteran las dimensiones del tracto resonador.",
      "Sonidos graves: resuenan en el pecho.",
      "Sonidos medios: resuenan detrás de la nariz.",
      "Sonidos agudos: resuenan en la cabeza.",
      "Voz mixta: Resuena principalmente en la faringe, conectando la voz de pecho y la voz de cabeza.",
      "El velo del paladar afecta la calidad del sonido (elevado redondea, caído produce nasalidad).",
    ],
    practicalTips: {
      title: "A tener en cuenta",
      tips: [
        "Sensibilidad: Percibir cómo la vibración se traslada por el cuerpo al cambiar de registros.",
        "Postura: Mantener una postura erguida para facilitar la resonancia natural.",
        "Relajación: Evitar tensiones en la garganta y el cuello para permitir que el sonido fluya libremente.",
        "Explorar registros: Sentir la resonancia en diferentes partes del cuerpo según el tono.",
        "Trabajar el velo del paladar: Elevarlo (como al bostezar) para redondear el sonido.",
        "Coordinación: Activar la parte blanda del paladar mientras  para redondear el sonido.",
        "Coordinación: Activar la parte blanda del paladar mientras se baja la parte posterior de la lengua para mantener la laringe estable.",
        "Imaginar el sonido como una onda que viaja por los resonadores.",
        "Visualizar el velo del paladar elevado y la laringe baja.",
        "Concentrarse en la sensación de vibración en el pecho, la cabeza y la nariz.",
        "Evitar forzar el sonido; dejar que la resonancia ocurra naturalmente.",
        "Usar ejercicios de bostezo para activar el velo del paladar y estabilizar la laringe.",
        "Practicar la transición suave entre registros para sentir cómo cambia la resonancia.",
      ],
    },
    exercises: [
      {
        id: "resonance-exploration",
        title: "Exploración de resonancia",
        description: "Sentir cómo la resonancia cambia al pasar de notas graves a agudas.",
        steps: [
          {
            id: "step-1",
            instruction: "Vibración en el pecho",
            description:
              'Produce un sonido grave con la vocal "o" y coloca tu mano en el pecho para sentir la vibración. Mantén el sonido durante 5-10 segundos.',
          },
          {
            id: "step-2",
            instruction: "Vibración en la cabeza",
            description:
              'Produce un sonido agudo con la vocal "i" y coloca tus manos en los lados de la cabeza para sentir la vibración. Mantén el sonido durante 5-10 segundos.',
          },
          {
            id: "step-3",
            instruction: "Transición de resonancia",
            description:
              'Realiza un glissando desde una nota grave hasta una aguda con la vocal "u", sintiendo cómo la resonancia se desplaza desde el pecho hacia la cabeza.',
          },
        ],
        videoUrl: "https://www.youtube.com/watch?v=BBZsvZgSbX4",
      },
      {
        id: "palate-work",
        title: "Trabajo con el velo del paladar",
        description: "Practicar la elevación del velo del paladar para mejorar la resonancia.",
        steps: [
          {
            id: "step-1",
            instruction: "Bostezo",
            description:
              "Imita un bostezo suave y observa cómo se eleva el velo del paladar. Mantén esa sensación de apertura.",
          },
          {
            id: "step-2",
            instruction: "Sonido nasal vs. redondeado",
            description:
              'Produce un sonido nasal (como "n") y luego un sonido redondeado (como "o"). Alterna entre ambos para sentir la diferencia en la posición del velo del paladar.',
          },
          {
            id: "step-3",
            instruction: "Vocalización con paladar elevado",
            description:
              "Canta una escala simple manteniendo la sensación de bostezo y el velo del paladar elevado. Observa cómo cambia la calidad del sonido.",
          },
        ],
      },
      {
        id: "register-transition",
        title: "Transición de registros",
        description: "Practicar la transición suave entre los diferentes registros vocales.",
        steps: [
          {
            id: "step-1",
            instruction: "Voz de pecho",
            description:
              'Canta notas graves con la vocal "a", sintiendo la resonancia en el pecho. Mantén cada nota durante 3-5 segundos.',
          },
          {
            id: "step-2",
            instruction: "Voz mixta",
            description:
              'Canta notas medias con la vocal "e", sintiendo la resonancia en la faringe (garganta). Mantén cada nota durante 3-5 segundos.',
          },
          {
            id: "step-3",
            instruction: "Voz de cabeza",
            description:
              'Canta notas agudas con la vocal "i", sintiendo la resonancia en la cabeza. Mantén cada nota durante 3-5 segundos.',
          },
          {
            id: "step-4",
            instruction: "Transición suave",
            description:
              "Realiza un glissando lento desde una nota grave hasta una aguda y viceversa, manteniendo un sonido continuo y suave a través de todos los registros.",
          },
        ],
        videoUrl: "https://www.youtube.com/watch?v=OPZkCCvBSt0",
        allowCustomVideo: true,
      },
    ],
  },
  {
    id: "articulators",
    title: "Articuladores",
    description:
      "Aprende a utilizar correctamente los articuladores para mejorar la claridad y expresividad de tu voz.",
    mainTopics: [
      "Articulación: Proceso de producir sonidos del habla mediante el movimiento de la lengua, labios, mandíbula y velo del paladar.",
      "Es un hábito aprendido desde la infancia, influenciado por el entorno cultural.",
      "Una articulación clara y precisa mejora la resonancia, la proyección y la amplitud del registro vocal.",
      "La falta de apertura de la mandíbula y la poca activación del velo del paladar dificultan la claridad del sonido.",
      "Boca: Principal amplificador de la voz, limitada por los labios y las arcadas dentarias.",
      "Mandíbula: Conectada al cráneo por la articulación temporomandibular, permite movimientos de ascenso y descenso.",
      "Lengua: Órgano móvil dividido en tres porciones (punta, dorso y base), crucial para la articulación.",
      "Velo del paladar: Eleva y baja para modificar la resonancia y evitar la nasalidad.",
      "Labios: Músculo orbicular que rodea la boca, esencial para la claridad y proyección del sonido.",
      "El timbre de la voz está determinado por la forma de los maxilares y las cavidades articulatorias.",
      "Los movimientos de los articuladores modifican el tracto vocal, afectando la resonancia y la calidad del sonido.",
    ],
    practicalTips: {
      title: "A tener en cuenta",
      tips: [
        "Apertura de la mandíbula: Evitar la rigidez y permitir un movimiento libre y relajado.",
        "Activación del velo del paladar: Elevarlo para mejorar la resonancia y evitar sonidos nasales.",
        "Movilidad de la lengua: Mantenerla flexible y coordinada con el paladar blando.",
        "Claridad en los labios: Usar el músculo orbicular para definir las palabras y proyectar el sonido.",
        "Relajación sostenida: Evitar tensiones en la mandíbula y la cara mientras se articula.",
        "Coordinación: Trabajar la relación opuesta entre la base de la lengua y el velo del paladar.",
        'Proyección: Imaginar el sonido saliendo "en la máscara" para mejorar la claridad y resonancia.',
        "Visualizar la boca como un amplificador que modifica el sonido.",
        "Concentrarse en la sensación de movimiento en los labios, lengua y mandíbula.",
        "Imaginar el sonido como un flujo constante y elástico.",
        "Practicar movimientos suaves y controlados de los articuladores.",
        "Evitar forzar la mandíbula o tensar los labios.",
      ],
    },
    exercises: [
      {
        id: "jaw-mobility",
        title: "Movilidad de la mandíbula",
        description: "Ejercicios para mejorar la flexibilidad y relajación de la mandíbula.",
        steps: [
          {
            id: "step-1",
            instruction: "Apertura y cierre suave",
            description:
              "Abre y cierra la mandíbula lentamente, sintiendo la relajación en los músculos. Repite 10 veces.",
          },
          {
            id: "step-2",
            instruction: "Movimientos laterales",
            description:
              "Mueve la mandíbula de lado a lado sin forzar, como si estuvieras masticando lentamente. Repite 10 veces en cada dirección.",
          },
          {
            id: "step-3",
            instruction: "Círculos con la mandíbula",
            description:
              "Realiza movimientos circulares suaves con la mandíbula, primero en sentido horario y luego antihorario. Repite 5 veces en cada dirección.",
          },
        ],
      },
      {
        id: "lip-exercises",
        title: "Ejercicios de labios",
        description: "Ejercicios para mejorar la flexibilidad y control de los labios.",
        steps: [
          {
            id: "step-1",
            instruction: "Vibración de labios",
            description:
              "Haz vibrar los labios (como un motor) para relajar y activar el músculo orbicular. Mantén la vibración durante 5-10 segundos.",
          },
          {
            id: "step-2",
            instruction: "Estiramiento de labios",
            description:
              'Alterna entre sonreír ampliamente (estirando los labios) y formar una "o" pequeña con los labios. Repite 10 veces.',
          },
          {
            id: "step-3",
            instruction: "Pronunciación exagerada",
            description:
              'Pronuncia las vocales "a-e-i-o-u" exagerando el movimiento de los labios. Repite la secuencia 5 veces.',
          },
        ],
      },
      {
        id: "articulation-singing",
        title: "Articulación en el canto",
        description: "Aplicar los conceptos de articulación a ejercicios vocales y canciones.",
        steps: [
          {
            id: "step-1",
            instruction: "Escalas con vocales",
            description:
              "Canta escalas ascendentes y descendentes con diferentes vocales (a, e, i, o, u), enfocándote en la claridad de cada vocal.",
          },
          {
            id: "step-2",
            instruction: "Trabalenguas cantado",
            description:
              "Canta un trabalenguas simple con una melodía sencilla, enfocándote en la precisión de la articulación.",
          },
          {
            id: "step-3",
            instruction: "Frases con proyección",
            description:
              "Canta frases cortas imaginando que proyectas el sonido hacia un punto lejano, manteniendo la claridad en la articulación.",
          },
          {
            id: "step-4",
            instruction: "Canción con articulación consciente",
            description:
              "Canta una canción prestando especial atención a la articulación de cada palabra, exagerando ligeramente los movimientos de los articuladores.",
          },
        ],
        videoUrl: "https://www.youtube.com/watch?v=ZVeFfGW8sgQ",
        allowCustomVideo: true,
      },
    ],
  },
]

