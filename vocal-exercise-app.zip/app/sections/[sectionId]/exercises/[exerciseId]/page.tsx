"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { notFound } from "next/navigation"
import { sections } from "@/data/sections"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { YouTubePlayer } from "@/components/youtube-player"
import { useProgress } from "@/context/progress-context"

export default function ExercisePage({
  params,
}: {
  params: { sectionId: string; exerciseId: string }
}) {
  const router = useRouter()
  const { markExerciseCompleted } = useProgress()
  const [currentStepIndex, setCurrentStepIndex] = useState(0)

  const section = sections.find((s) => s.id === params.sectionId)
  if (!section) {
    notFound()
  }

  const exercise = section.exercises.find((e) => e.id === params.exerciseId)
  if (!exercise) {
    notFound()
  }

  const currentStep = exercise.steps[currentStepIndex]
  const isFirstStep = currentStepIndex === 0
  const isLastStep = currentStepIndex === exercise.steps.length - 1

  const handleNext = () => {
    if (isLastStep) {
      markExerciseCompleted(params.sectionId as any, params.exerciseId)
      router.push(`/sections/${params.sectionId}/complete`)
    } else {
      setCurrentStepIndex((prev) => prev + 1)
    }
  }

  const handlePrevious = () => {
    setCurrentStepIndex((prev) => Math.max(0, prev - 1))
  }

  return (
    <div className="container py-8 max-w-4xl">
      <div className="mb-8">
        <Link href={`/sections/${section.id}/exercises`} className="text-primary hover:underline mb-4 inline-block">
          ← Volver a ejercicios
        </Link>
        <h1 className="text-3xl font-bold mb-2">{exercise.title}</h1>
        <p className="text-muted-foreground">{exercise.description}</p>
      </div>

      {exercise.videoUrl && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Video de referencia</CardTitle>
          </CardHeader>
          <CardContent>
            <YouTubePlayer defaultVideoUrl={exercise.videoUrl} allowCustomVideo={exercise.allowCustomVideo} />
          </CardContent>
        </Card>
      )}

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>
            Paso {currentStepIndex + 1} de {exercise.steps.length}: {currentStep.instruction}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="w-full">
            <p className="mb-6">{currentStep.description}</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button onClick={handlePrevious} variant="outline" disabled={isFirstStep}>
          ← Paso anterior
        </Button>
        <Button onClick={handleNext}>{isLastStep ? "Completar ejercicio" : "Siguiente paso →"}</Button>
      </div>
    </div>
  )
}

