import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Section } from "@/types"

interface SectionCardProps {
  section: Section
  completed?: number
  total?: number
}

export function SectionCard({ section, completed, total }: SectionCardProps) {
  const progress = completed !== undefined && total ? Math.round((completed / total) * 100) : undefined

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <CardTitle>{section.title}</CardTitle>
        <CardDescription>{section.description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        {progress !== undefined && (
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Progreso</span>
              <span>{progress}%</span>
            </div>
            <div className="w-full bg-secondary rounded-full h-2.5">
              <div className="bg-primary h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
          </div>
        )}
        <p className="text-sm text-muted-foreground">{section.mainTopics[0].substring(0, 100)}...</p>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full">
          <Link href={`/sections/${section.id}`}>{completed === 0 ? "Comenzar" : "Continuar"}</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

