import Link from "next/link"
import { notFound } from "next/navigation"
import { sections } from "@/data/sections"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function SectionPage({ params }: { params: { sectionId: string } }) {
  const section = sections.find((s) => s.id === params.sectionId)

  if (!section) {
    notFound()
  }

  return (
    <div className="container py-8">
      <div className="mb-8">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>
        <h1 className="text-3xl font-bold mb-2">{section.title}</h1>
        <p className="text-muted-foreground">{section.description}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Temas principales</CardTitle>
            <CardDescription>Conceptos fundamentales</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5 space-y-2">
              {section.mainTopics.map((topic, index) => (
                <li key={index} className="text-sm">
                  {topic}
                </li>
              ))}
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full">
              <Link href={`/sections/${section.id}/main`}>Ver temas principales</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Consejos prácticos</CardTitle>
            <CardDescription>Recomendaciones útiles</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5 space-y-2">
              {section.practicalTips.tips.slice(0, 5).map((tip, index) => (
                <li key={index} className="text-sm">
                  {tip}
                </li>
              ))}
              {section.practicalTips.tips.length > 5 && (
                <li className="text-sm text-muted-foreground">
                  Y {section.practicalTips.tips.length - 5} consejos más...
                </li>
              )}
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full">
              <Link href={`/sections/${section.id}/tips`}>Ver consejos prácticos</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ejercicios</CardTitle>
            <CardDescription>Práctica y aplicación</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5 space-y-2">
              {section.exercises.map((exercise, index) => (
                <li key={index} className="text-sm">
                  {exercise.title}
                </li>
              ))}
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full">
              <Link href={`/sections/${section.id}/exercises`}>Ver ejercicios</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

