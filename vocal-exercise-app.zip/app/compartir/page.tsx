"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Share2, Download, Copy, Check } from "lucide-react"

export default function CompartirPage() {
  const [appUrl, setAppUrl] = useState("")
  const [qrCodeUrl, setQrCodeUrl] = useState("")
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    // Obtener la URL actual
    const url = window.location.origin
    setAppUrl(url)

    // Generar URL del código QR usando una API gratuita
    setQrCodeUrl(`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(url)}`)
  }, [])

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Ejercitación Vocal",
          text: "¡Prueba esta aplicación de ejercicios vocales!",
          url: appUrl,
        })
      } catch (error) {
        console.error("Error al compartir:", error)
      }
    }
  }

  return (
    <div className="container py-8 max-w-md">
      <div className="mb-8">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>
        <h1 className="text-3xl font-bold mb-2">Compartir aplicación</h1>
        <p className="text-muted-foreground">Comparte esta aplicación con tus amigos</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Código QR</CardTitle>
          <CardDescription>Escanea este código para acceder a la aplicación</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center">
          {qrCodeUrl && (
            <div className="mb-6 p-4 bg-white rounded-lg">
              <img src={qrCodeUrl || "/placeholder.svg"} alt="Código QR" width={200} height={200} />
            </div>
          )}

          <div className="grid gap-4 w-full">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={appUrl}
                readOnly
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
              <Button variant="outline" size="icon" onClick={handleCopyLink}>
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {navigator.share && (
                <Button onClick={handleShare}>
                  <Share2 className="mr-2 h-4 w-4" />
                  Compartir
                </Button>
              )}
              <Button variant="outline" asChild>
                <a href={qrCodeUrl} download="ejercitacion-vocal-qr.png">
                  <Download className="mr-2 h-4 w-4" />
                  Descargar QR
                </a>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

