import { NavigationContainer } from "@react-navigation/native"
import { createNativeStackNavigator } from "@react-navigation/native-stack"
import { SafeAreaView, StyleSheet, Text, View, TouchableOpacity, FlatList } from "react-native"
import { sections } from "./data/sections"

const Stack = createNativeStackNavigator()

function HomeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Ejercitación Vocal</Text>
        <Text style={styles.subtitle}>Mejora tu técnica vocal con estos ejercicios</Text>
      </View>

      <FlatList
        data={sections}
        numColumns={2}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate("Section", { sectionId: item.id })}>
            <Text style={styles.cardTitle}>{item.title}</Text>
            <Text style={styles.cardDescription}>{item.description}</Text>
            <View style={styles.button}>
              <Text style={styles.buttonText}>Comenzar</Text>
            </View>
          </TouchableOpacity>
        )}
        contentContainerStyle={styles.grid}
      />

      <TouchableOpacity style={styles.progressButton} onPress={() => navigation.navigate("Progress")}>
        <Text style={styles.progressButtonText}>Ver mi progreso</Text>
      </TouchableOpacity>
    </SafeAreaView>
  )
}

// Otros componentes de pantalla irían aquí...

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
        {/* Otras pantallas irían aquí */}
      </Stack.Navigator>
    </NavigationContainer>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    padding: 20,
    alignItems: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: "#666",
  },
  grid: {
    padding: 16,
  },
  card: {
    flex: 1,
    margin: 8,
    padding: 16,
    backgroundColor: "#fff",
    borderRadius: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 8,
  },
  cardDescription: {
    fontSize: 14,
    color: "#666",
    marginBottom: 16,
  },
  button: {
    backgroundColor: "#3b82f6",
    padding: 10,
    borderRadius: 4,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  progressButton: {
    margin: 20,
    padding: 16,
    backgroundColor: "#3b82f6",
    borderRadius: 8,
    alignItems: "center",
  },
  progressButtonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
})

