export type SectionType = "breathing" | "vibration" | "resonance" | "articulators"

export type ContentType = "main" | "tips" | "exercises"

export interface Exercise {
  id: string
  title: string
  description: string
  steps: ExerciseStep[]
  videoUrl?: string
  allowCustomVideo?: boolean
}

export interface ExerciseStep {
  id: string
  instruction: string
  description: string
  imageUrl?: string
}

export interface Section {
  id: SectionType
  title: string
  description: string
  mainTopics: string[]
  practicalTips: {
    title: string
    tips: string[]
  }
  exercises: Exercise[]
}

export interface Progress {
  date: string
  completedSections: {
    sectionId: SectionType
    exercisesCompleted: string[]
  }[]
}

