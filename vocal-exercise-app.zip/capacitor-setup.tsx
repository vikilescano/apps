// Este es un archivo de instrucciones, no parte del código

// 1. Instalar Capacitor
// npm install @capacitor/core @capacitor/cli
// npm install @capacitor/ios @capacitor/android

// 2. Inicializar Capacitor
// npx cap init "Ejercitación Vocal" "com.tuempresa.ejercitacionvocal"

// 3. Agregar plataformas
// npx cap add ios
// npx cap add android

// 4. Construir la aplicación Next.js
// npm run build

// 5. Copiar la aplicación web a las plataformas nativas
// npx cap copy

// 6. Abrir los proyectos nativos en sus respectivos IDEs
// npx cap open ios
// npx cap open android

