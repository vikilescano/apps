import Link from "next/link"
import { notFound } from "next/navigation"
import { sections } from "@/data/sections"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function MainTopicsPage({ params }: { params: { sectionId: string } }) {
  const section = sections.find((s) => s.id === params.sectionId)

  if (!section) {
    notFound()
  }

  return (
    <div className="container py-8 max-w-4xl">
      <div className="mb-8">
        <Link href={`/sections/${section.id}`} className="text-primary hover:underline mb-4 inline-block">
          ← Volver a {section.title}
        </Link>
        <h1 className="text-3xl font-bold mb-2">Temas principales: {section.title}</h1>
        <p className="text-muted-foreground">{section.description}</p>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Conceptos fundamentales</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-4">
            {section.mainTopics.map((topic, index) => (
              <li key={index} className="flex gap-3">
                <span className="flex-shrink-0 bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm">
                  {index + 1}
                </span>
                <span>{topic}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button asChild variant="outline">
          <Link href={`/sections/${section.id}`}>Volver</Link>
        </Button>
        <Button asChild>
          <Link href={`/sections/${section.id}/tips`}>Consejos prácticos →</Link>
        </Button>
      </div>
    </div>
  )
}

