"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { notFound } from "next/navigation"
import { sections } from "@/data/sections"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useProgress } from "@/context/progress-context"
import type { SectionType } from "@/types"

export default function CompletePage({ params }: { params: { sectionId: string } }) {
  const router = useRouter()
  const { getTodayProgress } = useProgress()

  const section = sections.find((s) => s.id === params.sectionId)
  if (!section) {
    notFound()
  }

  const todayProgress = getTodayProgress()
  const completedSections = todayProgress.filter((p) => p.completed > 0)
  const allSectionsCompleted = completedSections.length === sections.length

  // Get incomplete sections
  const incompleteSections = sections.filter((s) => {
    const progress = todayProgress.find((p) => p.sectionId === s.id)
    return !progress || progress.completed < progress.total
  })

  const handleContinue = (sectionId: SectionType) => {
    router.push(`/sections/${sectionId}`)
  }

  return (
    <div className="container py-8 max-w-4xl">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold mb-2">¡Ejercicio completado!</h1>
        <p className="text-muted-foreground">Has completado un ejercicio de {section.title}</p>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Tu progreso de hoy</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {todayProgress.map((progress) => {
              const sectionData = sections.find((s) => s.id === progress.sectionId)
              return (
                <div key={progress.sectionId} className="flex items-center gap-4">
                  <div className="flex-grow">
                    <p className="font-medium">{sectionData?.title}</p>
                    <div className="w-full bg-secondary rounded-full h-2.5 mt-1">
                      <div
                        className="bg-primary h-2.5 rounded-full"
                        style={{ width: `${(progress.completed / progress.total) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="text-sm">
                    {progress.completed}/{progress.total}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">¿Qué quieres hacer ahora?</h2>

        {allSectionsCompleted ? (
          <Card>
            <CardContent className="pt-6">
              <p className="mb-4 text-center">¡Has completado todos los ejercicios de hoy! 🎉</p>
              <Button asChild className="w-full">
                <Link href="/progress">Ver mi progreso completo</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Terminar por hoy</CardTitle>
              </CardHeader>
              <CardContent>
                <Button asChild className="w-full">
                  <Link href="/progress">Ver mi progreso</Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Continuar ejercitando</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  {incompleteSections.map((section) => (
                    <Button
                      key={section.id}
                      onClick={() => handleContinue(section.id as SectionType)}
                      variant="outline"
                      className="w-full justify-start"
                    >
                      {section.title}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <div className="text-center">
        <Button asChild variant="outline">
          <Link href="/">Volver al inicio</Link>
        </Button>
      </div>
    </div>
  )
}

