import Link from "next/link"
import { notFound } from "next/navigation"
import { sections } from "@/data/sections"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ExercisesPage({ params }: { params: { sectionId: string } }) {
  const section = sections.find((s) => s.id === params.sectionId)

  if (!section) {
    notFound()
  }

  return (
    <div className="container py-8 max-w-4xl">
      <div className="mb-8">
        <Link href={`/sections/${section.id}`} className="text-primary hover:underline mb-4 inline-block">
          ← Volver a {section.title}
        </Link>
        <h1 className="text-3xl font-bold mb-2">Ejercicios: {section.title}</h1>
        <p className="text-muted-foreground">{section.description}</p>
      </div>

      <div className="grid gap-6 mb-8">
        {section.exercises.map((exercise) => (
          <Card key={exercise.id}>
            <CardHeader>
              <CardTitle>{exercise.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">{exercise.description}</p>
              <Button asChild className="w-full">
                <Link href={`/sections/${section.id}/exercises/${exercise.id}`}>Comenzar ejercicio</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-between">
        <Button asChild variant="outline">
          <Link href={`/sections/${section.id}/tips`}>← Consejos prácticos</Link>
        </Button>
        <Button asChild>
          <Link href="/">Volver al inicio</Link>
        </Button>
      </div>
    </div>
  )
}

